#' Discrete probability distribution sampler
#'
#' Generate a random number from a discrete probability distribution.
#'
#' @param p numeric vector of lenght K, specifying the probability for the K possible classes. It should sum 1.
#'
#' @return An integer number from 1 to K.
#' @export
#'
#' @examples rDiscreta(p=rep(1/6,6)) # simulate a dice rolling
#'
rDiscreta<-function(p){
  u<-runif(1)
  P<-cumsum(p)
  val<-sum(P<u)+1
  return(val)}

#' Density of a Student's t-distribution
#'
#' Calculate the density function of a Student's t-distribution at point yij with degrees of freedom equal to ni, mean equal to mu and scaling parameter equal to desvio.
#'
#' @param yij a numerical value. It also can be a vector of quantiles.
#' @param ni the degrees of freedom of the Student's t-distribution. It also can be a vector of degrees of freedom.
#' @param mu the mean of the Student's t-distribution. It also can be a vector of means.
#' @param desvio the scaling parameter of the Student's t-distribution. It should not be squared. It also can be a vector of scaling parameters.
#'
#' @return the value of the Student's t-distribution density at point yij.
#' @export
#'
#' @examples dstudentt(yij=c(1.2,2.3),ni=c(1,1),mu=c(1,2),desvio=c(3,3))
#'
dstudentt<-function(yij,ni,mu,desvio){
  dens<-exp(lgamma((ni+1)/2)-lgamma(ni/2))/(sqrt(pi*ni)*desvio)*((1+(1/ni)*((yij-mu)/desvio)**2)**(-(ni+1)/2))
  return(dens)}

#' Parameters of the posterior distribution of theta for the k-th cluster
#'
#' Compute the parameters of the posterior distribution of theta for the k-th cluster.
#'
#' @param yi a matrix of observations allocated at k-th cluster. Each row represents one individual and each column consists of the value of one variable for that individual.
#' @param mui a column matrix which specifies the value of hyperparameter mu (mean) in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows in this matrix should be the number of variables considered in data analysis.
#' @param lambdai a column matrix which specifies the value of hyperparameter lambda in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis.
#' @param alfai a column matrix which specifies the value of hyperparameter alpha in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis.
#' @param betai a column matrix which specifies the value of hyperparameter beta in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis.
#' @param nki the number of individuals allocated in k-th cluster.
#'
#' @return a list of updated parameters: mui, lambdai, alfai, betai and two vectors: the former with the average of each variable and the latter with the squared sum of each variable.
#' @export
#'
#' @examples data(iris)
#'setosa<-iris[which(iris[,5]=='setosa'),1:4]
#'setosa<-transfdata(setosa)
#'pars<-postparamvarunyis(yi=setosa,mui=matrix(0,ncol=1,nrow=ncol(setosa)),lambdai=matrix(0.1,nrow=ncol(setosa),ncol=1),alfai=matrix(5,nrow=ncol(setosa),ncol=1),betai=matrix(3,nrow=ncol(setosa),ncol=1),nki=nrow(setosa))
#'pars
#'
postparamvarunyis<-function(yi,mui,lambdai,alfai,betai,nki){
  if (nki>1){
    ykmean<-apply(yi,2,mean)
    yksumsquar<-apply(yi**2,2,sum)}
  if (nki==1){
    ykmean<-yi
    yksumsquar<-yi**2}
  munew<-(ykmean*nki+lambdai*mui)/(lambdai+nki)
  lambdanew<-lambdai+nki
  agamnew<-alfai+(nki/2)
  s2<-yksumsquar-(nki*ykmean**2)
  bgamnew<-betai+(s2+((nki*lambdai*(ykmean-mui)**2)/(lambdai+nki)))/2
  list(munew,lambdanew,agamnew,bgamnew,ykmean,yksumsquar)}


#' Marginal distribution of yi
#'
#' Compute the log-marginal distribution of yi
#'
#' @param mlkj the number of individuals allocated in k-th cluster.
#' @param media a vector of averages where each element is the mean of one variable for individuals allocated in k-th cluster.
#' @param varia a vector of squared sum where each element is the squared sum of one variable for individuals allocated in k-th cluster.
#' @param lambda a vector which specifies the value of parameter lambda for the Normal Inverse Gamma posterior distribution of theta for k-th cluster. The number of elements in this vector should be the number of variables considered in data analysis.
#' @param agam a vector which specifies the value of parameter alpha for the Normal Inverse Gamma posterior distribution of theta for k-th cluster. The number of elements in this vector should be the number of variables considered in data analysis.
#' @param bgam a vector which specifies the value of parameter beta for the Normal Inverse Gamma posterior distribution of theta for k-th cluster. The number of elements in this vector should be the number of variables considered in data analysis.
#' @param mu a vector which specifies the value of parameter mu for the Normal Inverse Gamma posterior distribution of theta for k-th cluster. The number of elements in this vector should be the number of variables considered in data analysis.
#'
#' @return a vector of values which represent the log-marginal density for each variable considered in the data analysis. As we suppose variables are independent, the complete log-marginal is obtained by summing the elements of this vector.
#' @export
#'
#' @examples data(iris)
#' setosa<-iris[which(iris[,5]=='setosa'),1:4]
#' setosa<-transfdata(setosa)
#' pars<-postparamvarunyis(yi=setosa,mui=matrix(0,ncol=1,nrow=ncol(setosa)),lambdai=matrix(0.1,nrow=ncol(setosa),ncol=1),alfai=matrix(5,nrow=ncol(setosa),ncol=1),betai=matrix(3,nrow=ncol(setosa),ncol=1),nki=nrow(setosa))
#' sum(dmarglikeli(mlkj=nrow(setosa),media=pars[[5]],varia=pars[[6]],lambda=pars[[2]],agam=pars[[3]],bgam=pars[[4]],mu=pars[[1]]))
#'
dmarglikeli<-function(mlkj,media,varia,lambda,agam,bgam,mu){
  logdens<-(lgamma(mlkj/2+agam)-lgamma(agam))+((-mlkj/2)*log(2*pi))+(0.5*(log(lambda)-log(mlkj+lambda)))+(agam*log(bgam))+((-(mlkj/2+agam))*log(bgam+(varia/2)+((lambda*mlkj*((media-mu)**2))/(2*(mlkj+lambda)))))
  return(logdens)}
