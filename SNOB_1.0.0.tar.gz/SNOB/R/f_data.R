#' Transformation to get independent data
#'
#' Transform data using Cholesky decomposition to get independent and standardized variables
#'
#' @param Y a matrix with the data to be analyzed: rows represent different individuals and colunms represent different variables. Missing values are not allowed.
#'
#' @return a matrix with the new data where variables are independent and standardized.
#' @export
#'
#' @examples data(iris)
#' iris_new<-transfdata(Y=iris[,1:4])
#'
transfdata<-function(Y){
  covmat<-cov(Y)
  decomp<-t(chol(covmat))
  Ytransf<-t(solve(decomp)%*%t(Y))
  media<-apply(Ytransf,2,mean)
  for (j in 1:ncol(Ytransf)) Ytransf[,j]<-Ytransf[,j]-media[j]
  return(Ytransf)}


#' Split data in shards
#'
#' Randomly split the data in shards
#' @param dados a matrix with the data to be analyzed: rows represent different individuals and colunms represent different variables. Missing values are not allowed. For performing SNOB clustering method this argument should be an object from 'transfdata' function.
#' @param batches a integer value which specifies the number of shards the data will be split.
#' @param directory a directory in your computer where the intermediate files will be saved.
#'
#' @return A list containing the data of each shard. Files called 'Shardb.txt', where b=1,...,batches, will also be saved in the specified directory. Those files specify the individuals allocated in each shard.
#' @export
#'
#' @examples data(iris)
#' iris_new<-transfdata(iris[,1:4])
#' dados<-split_data_shards(dados=iris_new,batches=2,directory="/Users/Daiane/Downloads/")
#'
split_data_shards<-function(dados,batches,directory){
  amostra<-1:nrow(dados)
  for (b in 1:(batches-1)){
    assign(paste("b",b,sep=""),sort(sample(amostra,round(nrow(dados)/batches,0))))
    assign(paste("Yb",b,sep=""),dados[get(paste("b",b,sep="")),])
    amostra<-amostra[-which(amostra %in% get(paste("b",b,sep="")))]
    cat(get(paste("b",b,sep="")),file=paste(directory,"Shard",b,".txt",sep=""))}
  assign(paste("b",batches,sep=""),sort(amostra))
  assign(paste("Yb",batches,sep=""),dados[get(paste("b",batches,sep="")),])
  amostra<-amostra[-which(amostra %in% get(paste("b",batches,sep="")))]
  cat(get(paste("b",batches,sep="")),file=paste(directory,"Shard",batches,".txt",sep=""))
  #
  lista<-list(Yb1)
  for (b in 2:(batches)) lista[[length(lista)+1]]<-get(paste("Yb",b,sep=""))
  return(lista)}
