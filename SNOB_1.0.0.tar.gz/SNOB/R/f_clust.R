#' Gibbs sampling for local clusters
#'
#' Run the Gibbs sampling method to identify local clusters in each shard.
#'
#' @param Y a matrix with the data to be analyzed: rows represent different individuals and colunms represent different variables. Missing values are not allowed. For performing SNOB clustering method this argument should be one of all shards returned by 'split_data_shards' function.
#' @param Sj a initial configuration for the local clusters. The number of element should be the number of individuals available in Y. For initialization with just one cluster, Sj<-rep(1,nrow(Y)).
#' @param directory a directory in your computer where the intermediate files will be saved.
#' @param burnin a integer number that represents the number of initial iterations in MCMC chain that will be discarded before starting recording MCMC sample. The default value is 5000.
#' @param amostrasfin a integer number that represents the final lenght of MCMC sample after burnin and jumps. Just those iterations will be saved in intermediate files. The default value is 1000.
#' @param saltos a integer number that represents the lenght of jumps to record a new iteration. It should be greater than 0 and the default value is 5.
#' @param alpha a integer number that represents the value of total mass parameter of Dirichet process. The default value is 1.
#' @param mu0 a column matrix which specifies the value of hyperparameter mu (mean) in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows in this matrix should be the number of variables considered in data analysis. The default value is 0 for all considered variable.
#' @param lambda0 a column matrix which specifies the value of hyperparameter lambda in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis. The default value is 0.1 for all considered variable.
#' @param alfa0 a column matrix which specifies the value of hyperparameter alpha in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis. The default value is 5 for all considered variable.
#' @param beta0 a column matrix which specifies the value of hyperparameter beta in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis. The default value is 3 for all considered variable.
#' @param bat a integer number from 1 to B=number of shards the data were split. It specifies the number of the shard that will be clustered in this step.
#'
#' @return A file called "Sj_batchb.txt", for b=1,...,B, will be saved in the specified directory. That file consists of the number of the cluster each individual is allocated in each recorded MCMC iteration.
#' @export
#'
#' @examples data(iris)
#' iris_new<-transfdata(iris[,1:4])
#' dados<-split_data_shards(dados=iris_new,batches=2,directory="/Users/Daiane/Downloads/")
#' bat<-1
#' Gibbs_local(Y=dados[[bat]],Sj=rep(1,nrow(dados[[bat]])),directory="/Users/Daiane/Downloads/",burnin=2000,amostrasfin=1000,saltos=5,bat=bat)
#'
Gibbs_local<-function(Y,Sj,directory,burnin=5000,amostrasfin=1000,saltos=5,alpha=1,mu0=matrix(0,ncol=1,nrow=ncol(Y)),lambda0=matrix(0.1,nrow=ncol(Y),ncol=1),alfa0=matrix(5,nrow=ncol(Y),ncol=1),beta0=matrix(3,nrow=ncol(Y),ncol=1),bat){
  Nt<-nrow(Y)
  Dim<-ncol(Y)
  AmostrasTotal<-burnin+amostrasfin*saltos
  nk<-table(Sj)
  K<-length(nk)
  ni0<-2*alfa0
  mu0<-mu0
  desvio0<-sqrt((2*beta0*(1+lambda0))/(ni0*lambda0))
  #
  ykmean<-matrix(0,nrow=Dim,ncol=K)
  yksumsquar<-matrix(0,nrow=Dim,ncol=K)
  mupost<-matrix(0,nrow=Dim,ncol=K)
  lambdapost<-matrix(0,nrow=Dim,ncol=K)
  alfapost<-matrix(0,nrow=Dim,ncol=K)
  betapost<-matrix(0,nrow=Dim,ncol=K)
  for (k in 1:K){
    param<-postparamvarunyis(Y[which(Sj==k),],mu0,lambda0,alfa0,beta0,nk[k])
    mupost[,k]<-param[[1]]
    lambdapost[,k]<-param[[2]]
    alfapost[,k]<-param[[3]]
    betapost[,k]<-param[[4]]
    ykmean[,k]<-param[[5]]
    yksumsquar[,k]<-param[[6]]}
  #
  for (int in 1:AmostrasTotal){
    for (i in 1:Nt){
      nk<-numeric(K)
      for (k in 1:K) 	nk[k]<-sum(Sj[-i]==k)
      mupostnew<-mupost
      lambdapostnew<-lambdapost
      alfapostnew<-alfapost
      betapostnew<-betapost
      ykmeannew<-ykmean
      yksumsquarnew<-yksumsquar
      if (nk[Sj[i]]>0){
        param<-postparamvarunyis(Y[-c(which(Sj!=Sj[i]),i),],mu0,lambda0,alfa0,beta0,nk[Sj[i]])
        mupostnew[,Sj[i]]<-param[[1]]
        lambdapostnew[,Sj[i]]<-param[[2]]
        alfapostnew[,Sj[i]]<-param[[3]]
        betapostnew[,Sj[i]]<-param[[4]]
        ykmeannew[,Sj[i]]<-param[[5]]
        yksumsquarnew[,Sj[i]]<-param[[6]]}
      prob<-numeric(K)
      for (k in 1:K){
        ni<-2*alfapostnew[,k]
        mu<-mupostnew[,k]
        desvio<-sqrt((2*betapostnew[,k]*(1+lambdapostnew[,k]))/(ni*lambdapostnew[,k]))
        prob[k]<-nk[k]*prod(dstudentt(Y[i,],ni,mu,desvio))}
      prob<-c(prob,alpha*prod(dstudentt(Y[i,],ni0,mu0,desvio0)))
      Snew<-rDiscreta(prob/sum(prob))
      #
      if (Snew != Sj[i] & Snew <= K){
        Sj[i]<-Snew
        nk[Sj[i]]<-nk[Sj[i]]+1
        mupost<-mupostnew
        lambdapost<-lambdapostnew
        alfapost<-alfapostnew
        betapost<-betapostnew
        ykmean<-ykmeannew
        yksumsquar<-yksumsquarnew
        param<-postparamvarunyis(Y[which(Sj==Sj[i]),],mu0,lambda0,alfa0,beta0,nk[Sj[i]])
        mupost[,Sj[i]]<-param[[1]]
        lambdapost[,Sj[i]]<-param[[2]]
        alfapost[,Sj[i]]<-param[[3]]
        betapost[,Sj[i]]<-param[[4]]
        ykmean[,Sj[i]]<-param[[5]]
        yksumsquar[,Sj[i]]<-param[[6]]}
      if (Snew != Sj[i] & Snew > K){
        Sj[i]<-Snew
        nk<-c(nk,1)
        mupost<-mupostnew
        lambdapost<-lambdapostnew
        alfapost<-alfapostnew
        betapost<-betapostnew
        ykmean<-ykmeannew
        yksumsquar<-yksumsquarnew
        param<-postparamvarunyis(Y[which(Sj==Sj[i]),],mu0,lambda0,alfa0,beta0,nk[Sj[i]])
        mupost<-cbind(mupost,param[[1]])
        lambdapost<-cbind(lambdapost,param[[2]])
        alfapost<-cbind(alfapost,param[[3]])
        betapost<-cbind(betapost,param[[4]])
        ykmean<-cbind(ykmean,param[[5]])
        yksumsquar<-cbind(yksumsquar,param[[6]])}
      while (length(table(Sj))<max(Sj)){ # exclude empty clusters
        categr<-as.numeric(as.character(data.frame(table(Sj))[,1]))
        categd<-seq(1:length(table(Sj)))
        dif<-which(categr!=categd)
        Sj[which(Sj>dif[1])]<-Sj[which(Sj>dif[1])]-1
        mupost<-matrix(c(mupost[,-dif[1]]),nrow=Dim)
        lambdapost<-matrix(c(lambdapost[,-dif[1]]),nrow=Dim)
        alfapost<-matrix(c(alfapost[,-dif[1]]),nrow=Dim)
        betapost<-matrix(c(betapost[,-dif[1]]),nrow=Dim)
        ykmean<-matrix(c(ykmean[,-dif[1]]),nrow=Dim)
        yksumsquar<-matrix(c(yksumsquar[,-dif[1]]),nrow=Dim)
        K<-ncol(mupost)}
      if (length(table(Sj))<K){
        mupost<-matrix(c(mupost[,-K]),nrow=Dim)
        lambdapost<-matrix(c(lambdapost[,-K]),nrow=Dim)
        alfapost<-matrix(c(alfapost[,-K]),nrow=Dim)
        betapost<-matrix(c(betapost[,-K]),nrow=Dim)
        ykmean<-matrix(c(ykmean[,-K]),nrow=Dim)
        yksumsquar<-matrix(c(yksumsquar[,-K]),nrow=Dim)
        K<-ncol(mupost)}
      K<-ncol(mupost)}
    if (int>burnin & int%%saltos==0) cat('',Sj,file=paste(directory,"Sj_batch",bat,".txt",sep=""),append=T)}}

#' Gibbs sampling for local clusters in parallel
#'
#' Run the Gibbs sampling method to identify local clusters in each shard in parallel depending on the number of cores available in the processing computer. If the processing computer has just one core, the shards will be locally clustered in sequence.
#'
#' @param shards a list containing the data split in shards. It should be an object from 'split_data_shards' function.
#' @param directory a directory in your computer where the intermediate files will be saved.
#' @param burnin a integer number that represents the number of initial iterations in MCMC chain that will be discarded before starting recording MCMC sample. The default value is 5000.
#' @param amostrasfin a integer number that represents the final lenght of MCMC sample after burnin and jumps. Just those iterations will be saved in intermediate files. The default value is 1000.
#' @param saltos a integer number that represents the lenght of jumps to record a new iteration. It should be greater than 0 and the default value is 5.
#' @param alpha a integer number that represents the value of total mass parameter of Dirichet process. The default value is 1.
#' @param mu0 a column matrix which specifies the value of hyperparameter mu (mean) in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows in this matrix should be the number of variables considered in data analysis. The default value is 0 for all considered variable.
#' @param lambda0 a column matrix which specifies the value of hyperparameter lambda in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis. The default value is 0.1 for all considered variable.
#' @param alfa0 a column matrix which specifies the value of hyperparameter alpha in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis. The default value is 5 for all considered variable.
#' @param beta0 a column matrix which specifies the value of hyperparameter beta in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis. The default value is 3 for all considered variable.
#'
#'
#' @return Files called "Sj_batchb.txt", for b=1,...,B, will be saved in the specified directory. Those files consist of the number of the cluster each individual is allocated in each recorded MCMC iteration.
#' @export
#'
#' @examples data(iris)
#' iris_new<-transfdata(iris[,1:4])
#' dados<-split_data_shards(dados=iris_new,batches=2,directory="/Users/Daiane/Downloads/")
#' run_local_clusters_parallel(shards=dados,directory="/Users/Daiane/Downloads/",burnin=2000,amostrasfin=1000,saltos=5)
#'
run_local_clusters_parallel<-function(shards,directory,burnin=5000,amostrasfin=1000,saltos=5,alpha=1,mu0=matrix(0,ncol=1,nrow=ncol(shards[[1]])),lambda0=matrix(0.1,nrow=ncol(shards[[1]]),ncol=1),alfa0=matrix(5,nrow=ncol(shards[[1]]),ncol=1),beta0=matrix(3,nrow=ncol(shards[[1]]),ncol=1)){
  no_cores<-detectCores() - 1
  cl<-makeCluster(no_cores)
  registerDoParallel(cl)
  batches<-length(shards)
  foreach(b = 1:batches,.export=c("Gibbs_local","postparamvarunyis","dstudentt","rDiscreta")) %dopar% {
    Y<-shards[[b]]
    Nt<-nrow(Y)
    Dim<-ncol(Y)
    Sj<-rep(1,nrow(Y))
    Gibbs_local(Y,Sj,directory,burnin,amostrasfin,saltos,alpha,mu0,lambda0,alfa0,beta0,bat=b)}
  stopCluster(cl)}

#' Local clusters for each shard
#'
#' Define final local clusters for each shard
#'
#' @param directory a directory in your computer where the intermediate files built using 'run_local_clusters_parallel' or 'Gibbs_local' functions were saved.
#' @param arqu the name of file built by 'run_local_clusters_parallel' or 'Gibbs_local' functions. If you didn't change the original name of file, it will be paste("Sj_batch",b,".txt",sep=""), where b identifies the number of the shard that will be locally clustered.
#' @param Nt a integer value which represents the sample size of the shard that will be clustered.
#' @param thresh a real value in (0,100) interval which represents the co-clustering probability threshold to define if two individuals were be in the same cluster or not. We have smaller number of larger clusters for low values of thresh. The default value is 50.
#'
#' @return a numerical vector which represents the final local cluster for each individual in the analyzed shard.
#' @export
#'
#' @examples data(iris)
#' iris_new<-transfdata(iris[,1:4])
#' dados<-split_data_shards(dados=iris_new,batches=2,directory="/Users/Daiane/Downloads/")
#' run_local_clusters_parallel(shards=dados,directory="/Users/Daiane/Downloads/",burnin=2000,amostrasfin=1000,saltos=5)
#' cluster<-local_clust(directory="/Users/Daiane/Downloads/",arqu=paste("Sj_batch",1,".txt",sep=""),Nt=length(scan(file=paste(directory="/Users/Daiane/Downloads/","Shard",1,".txt",sep=""))))
#' cluster

local_clust<-function(directory,arqu,Nt,thresh=0.5*100){
  Sj<-scan(file=paste(directory,arqu,sep=""))
  Sj<-matrix(Sj,ncol=Nt,byrow=TRUE)
  #
  Sj.j<-Sj
  prob.eq<-matrix(0,nrow=ncol(Sj.j),ncol=ncol(Sj.j))
  for (i in 1:ncol(Sj.j)){
    for (j in 1:ncol(Sj.j)){
      prob.eq[i,j]<-round(sum(Sj.j[,i]==Sj.j[,j])/length(Sj.j[,i]),4)*100}}
  clust<-c(1,rep(0,(ncol(Sj.j)-1)))
  for (i in 2:ncol(Sj.j)){
    if (max(prob.eq[i,1:(i-1)])>thresh) clust[i]<-clust[which(prob.eq[i,1:(i-1)]==max(prob.eq[i,1:(i-1)]))[1]] else clust[i]<-max(clust[1:(i-1)]+1)}
  thesing<-0.3
  singl<-which(clust %in% which(table(clust)==1))
  if (length(singl)>1){
    prob.eq.sin<-prob.eq[singl,]
    for (i in 1:nrow(prob.eq.sin)){
      prob.eq.sin[i,singl[i]]<-0
      if (max(prob.eq.sin[i,])>thesing) clust[singl[i]]<-clust[which(prob.eq.sin[i,]==max(prob.eq.sin[i,]))[1]]}
    while (length(table(clust))<max(clust)){ # exclude empty clusters
      categr<-as.numeric(as.character(data.frame(table(clust))[,1]))
      categd<-seq(1:length(table(clust)))
      dif<-which(categr!=categd)
      clust[which(clust>dif[1])]<-clust[which(clust>dif[1])]-1}}
  return(clust)}

#' Gibbs sampling for global clusters
#'
#' Run the Gibbs sampling method to identify the global clusters using the local clusters for each shard. Local clusters for each shard are identified in parallel depending on the number of cores available in the processing computer. If the processing computer has just one core, the shards will be locally clustered in sequence.
#'
#' @param directory a directory in your computer where the intermediate files will be saved and where files with local clusters results are available.
#' @param shards a list containing the data split in shards. It should be an object from 'split_data_shards' function.
#' @param name_clustb a name for object which will contain the local clusters for each shard. The default name is 'clust'.
#' @param burnin a integer number that represents the number of initial iterations in MCMC chain that will be discarded before starting recording MCMC sample. The default value is 5000.
#' @param amostrasfin a integer number that represents the final lenght of MCMC sample after burnin and jumps. Just those iterations will be saved in intermediate files. The default value is 1000.
#' @param saltos a integer number that represents the lenght of jumps to record a new iteration. It should be greater than 0 and the default value is 5.
#' @param alpha a integer number that represents the value of total mass parameter of Dirichet process. The default value is 1.
#' @param mu0 a column matrix which specifies the value of hyperparameter mu (mean) in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows in this matrix should be the number of variables considered in data analysis. The default value is 0 for all considered variable.
#' @param lambda0 a column matrix which specifies the value of hyperparameter lambda in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis. The default value is 0.1 for all considered variable.
#' @param alfa0 a column matrix which specifies the value of hyperparameter alpha in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis. The default value is 5 for all considered variable.
#' @param beta0 a column matrix which specifies the value of hyperparameter beta in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis. The default value is 3 for all considered variable.
#' @param thresh a real value in (0,100) interval which represents the co-clustering probability threshold to define if two individuals were be in the same cluster or not. We have smaller number of larger clusters for low values of thresh. The default value is 50.
#'
#' @return a numerical vector which represents the final global cluster for each individual for the whole analyzed data. A file called "Global_cluster.txt" will also be saved in the specified directory. That file consists of the number of the global cluster each local cluster of all shards is allocated in each recorded MCMC iteration.
#' @export
#'
#' @examples data(iris)
#' iris_new<-transfdata(iris[,1:4])
#' dados<-split_data_shards(dados=iris_new,batches=2,directory="/Users/Daiane/Downloads/")
#' run_local_clusters_parallel(shards=dados,directory="/Users/Daiane/Downloads/",burnin=2000,amostrasfin=1000,saltos=5)
#' glob_clust<-Gibbs_global(directory="/Users/Daiane/Downloads/",shards=dados)
#' glob_clust
#'
Gibbs_global<-function(directory,shards=shards,name_clustb="clust",burnin=5000,amostrasfin=1000,saltos=5,alpha=1,mu0=matrix(0,ncol=1,nrow=ncol(shards[[1]])),lambda0=matrix(0.1,nrow=ncol(shards[[1]]),ncol=1),alfa0=matrix(5,nrow=ncol(shards[[1]]),ncol=1),beta0=matrix(3,nrow=ncol(shards[[1]]),ncol=1),thresh=0.5*100){
  batches<-length(shards)
  Nt<-numeric(length(shards))
  for (b in 1:length(shards)) Nt[b]<-length(scan(file=paste(directory,"Shard",b,".txt",sep="")))
  for (b in 1:length(shards)) assign(paste(name_clustb,b,sep=""),local_clust(directory,arqu=paste("Sj_batch",b,".txt",sep=""),Nt=Nt[b],thresh))
  Klocal<-numeric()
  for (b in 1:length(shards)) Klocal<-c(Klocal,length(table(get(paste(name_clustb,b,sep="")))))
  Zj<-seq(1:sum(Klocal))
  AmostrasTotal<-burnin+amostrasfin*saltos
  Klocal<-numeric()
  for (b in 1:batches) Klocal<-c(Klocal,length(table(get(paste(name_clustb,b,sep="")))))
  nk<-numeric(sum(Klocal))
  Dim<-ncol(shards[[b]])
  ykmean<-matrix(0,nrow=Dim,ncol=sum(Klocal))
  yksumsquar<-matrix(0,nrow=Dim,ncol=sum(Klocal))
  clus<-1
  for (b in 1:batches){
    for (k in 1:Klocal[b]){
      nk[clus]<-length(which(get(paste(name_clustb,b,sep=""))==k))
      if (nk[clus]>1){
        ykmean[,clus]<-apply(shards[[b]][which(get(paste(name_clustb,b,sep=""))==k),],2,mean)
        yksumsquar[,clus]<-apply(shards[[b]][which(get(paste(name_clustb,b,sep=""))==k),]**2,2,sum)}
      if (nk[clus]==1){
        ykmean[,clus]<-shards[[b]][which(get(paste(name_clustb,b,sep=""))==k),]
        yksumsquar[,clus]<-shards[[b]][which(get(paste(name_clustb,b,sep=""))==k),]**2}
      clus<-clus+1}}
  #
  Ynk<-nk
  Ymean<-ykmean
  Ysum<-matrix(0,ncol=ncol(Ymean),nrow=nrow(Ymean))
  for (i in 1:length(Ynk)) Ysum[,i]<-Ymean[,i]*Ynk[i]
  Ysumsquar<-yksumsquar
  Nt<-ncol(Ymean)
  #
  K<-length(table(Zj))
  nk<-numeric(K)
  for (k in 1:K) 	nk[k]<-sum(Ynk[which(Zj==k)])
  yksum<-matrix(0,ncol=K,nrow=nrow(Ymean))
  ykmean<-matrix(0,ncol=K,nrow=nrow(Ymean))
  yksumsquar<-matrix(0,ncol=K,nrow=nrow(Ymean))
  for (k in 1:K){
    if (length(which(Zj==k))>1){
      yksum[,k]<-apply(Ysum[,which(Zj==k)],1,sum)
      yksumsquar[,k]<-apply(Ysumsquar[,which(Zj==k)],1,sum)}
    if (length(which(Zj==k))==1){
      yksum[,k]<-Ysum[,which(Zj==k)]
      yksumsquar[,k]<-Ysumsquar[,which(Zj==k)]	}
    ykmean[,k]<-yksum[,k]/nk[k]}
  mupost<-matrix(0,nrow=Dim,ncol=K)
  lambdapost<-matrix(0,nrow=Dim,ncol=K)
  alfapost<-matrix(0,nrow=Dim,ncol=K)
  betapost<-matrix(0,nrow=Dim,ncol=K)
  for (k in 1:K){
    mupost[,k]<-(ykmean[,k]*nk[k]+lambda0*mu0)/(lambda0+nk[k])
    lambdapost[,k]<-lambda0+nk[k]
    alfapost[,k]<-alfa0+(nk[k]/2)
    s2<-yksumsquar[,k]-(nk[k]*ykmean[,k]**2)
    betapost[,k]<-beta0+(s2+((nk[k]*lambda0*(ykmean[,k]-mu0)**2)/(lambda0+nk[k])))/2}
  #
  for (int in 1:AmostrasTotal){
    for (i in 1:Nt){
      nk<-numeric(K)
      for (k in 1:K) 	nk[k]<-sum(Ynk[-c(which(Zj!=k),i)])
      mupostnew<-mupost
      lambdapostnew<-lambdapost
      alfapostnew<-alfapost
      betapostnew<-betapost
      yksumnew<-yksum
      ykmeannew<-ykmean
      yksumsquarnew<-yksumsquar
      if (nk[Zj[i]]>0){
        yksumnew[,Zj[i]]<-yksum[,Zj[i]]-Ysum[,i]
        ykmeannew[,Zj[i]]<-yksumnew[,Zj[i]]/(nk[Zj[i]])
        yksumsquarnew[,Zj[i]]<-yksumsquar[,Zj[i]]-Ysumsquar[,i]
        mupostnew[,Zj[i]]<-(ykmeannew[,Zj[i]]*nk[Zj[i]]+lambda0*mu0)/(lambda0+nk[Zj[i]])
        lambdapostnew[,Zj[i]]<-lambda0+nk[Zj[i]]
        alfapostnew[,Zj[i]]<-alfa0+(nk[Zj[i]]/2)
        s2<-yksumsquarnew[,Zj[i]]-(nk[Zj[i]]*ykmeannew[,Zj[i]]**2)
        betapostnew[,Zj[i]]<-beta0+(s2+((nk[Zj[i]]*lambda0*(ykmeannew[,Zj[i]]-mu0)**2)/(lambda0+nk[Zj[i]])))/2}
      prob<-numeric(K)
      varia<-Ysumsquar[,i]-(Ynk[i]*Ymean[,i]**2)
      for (k in 1:K) prob[k]<-sum(dmarglikeli(Ynk[i],Ymean[,i],varia,lambdapostnew[,k],alfapostnew[,k],betapostnew[,k],mupostnew[,k]))
      prob<-c(prob,sum(dmarglikeli(Ynk[i],Ymean[,i],varia,lambda0,alfa0,beta0,mu0)))
      mk<-nk
      if (nk[Zj[i]]==0) mk[Zj[i]]<-1
      mk<-c(lgamma(mk+Ynk[i])-lgamma(mk),(log(alpha)+lgamma(Ynk[i])))
      prob<-mk+prob
      prob<-exp(prob-max(prob))
      if (nk[Zj[i]]==0) prob[Zj[i]]<-0
      Snew<-rDiscreta(prob/sum(prob))
      #
      if (Snew != Zj[i] & Snew <= K){
        Zj[i]<-Snew
        nk[Zj[i]]<-nk[Zj[i]]+Ynk[i]
        mupost<-mupostnew
        lambdapost<-lambdapostnew
        alfapost<-alfapostnew
        betapost<-betapostnew
        yksum<-yksumnew
        ykmean<-ykmeannew
        yksumsquar<-yksumsquarnew
        yksum[,Zj[i]]<-yksum[,Zj[i]]+Ysum[,i]
        ykmean[,Zj[i]]<-yksum[,Zj[i]]/nk[Zj[i]]
        yksumsquar[,Zj[i]]<-yksumsquar[,Zj[i]]+Ysumsquar[,i]
        mupost[,Zj[i]]<-(ykmean[,Zj[i]]*nk[Zj[i]]+lambda0*mu0)/(lambda0+nk[Zj[i]])
        lambdapost[,Zj[i]]<-lambda0+nk[Zj[i]]
        alfapost[,Zj[i]]<-alfa0+(nk[Zj[i]]/2)
        s2<-yksumsquar[,Zj[i]]-(nk[Zj[i]]*ykmean[,Zj[i]]**2)
        betapost[,Zj[i]]<-beta0+(s2+((nk[Zj[i]]*lambda0*(ykmean[,Zj[i]]-mu0)**2)/(lambda0+nk[Zj[i]])))/2}
      if (Snew != Zj[i] & Snew > K){
        Zj[i]<-Snew
        nk<-c(nk,Ynk[i])
        yksum<-cbind(yksumnew,Ysum[,i])
        ykmean<-cbind(ykmeannew,Ymean[,i])
        yksumsquar<-cbind(yksumsquarnew,Ysumsquar[,i])
        mupost<-cbind(mupostnew,(ykmean[,Zj[i]]*nk[Zj[i]]+lambda0*mu0)/(lambda0+nk[Zj[i]]))
        lambdapost<-cbind(lambdapostnew,lambda0+nk[Zj[i]])
        alfapost<-cbind(alfapostnew,alfa0+(nk[Zj[i]]/2))
        s2<-yksumsquar[,Zj[i]]-(nk[Zj[i]]*ykmean[,Zj[i]]**2)
        betapost<-cbind(betapostnew,beta0+(s2+((nk[Zj[i]]*lambda0*(ykmean[,Zj[i]]-mu0)**2)/(lambda0+nk[Zj[i]])))/2)}
      while (length(table(Zj))<max(Zj)){ # exclude empty clusters
        categr<-as.numeric(as.character(data.frame(table(Zj))[,1]))
        categd<-seq(1:length(table(Zj)))
        dif<-which(categr!=categd)
        Zj[which(Zj>dif[1])]<-Zj[which(Zj>dif[1])]-1
        mupost<-matrix(c(mupost[,-dif[1]]),nrow=Dim)
        lambdapost<-matrix(c(lambdapost[,-dif[1]]),nrow=Dim)
        alfapost<-matrix(c(alfapost[,-dif[1]]),nrow=Dim)
        betapost<-matrix(c(betapost[,-dif[1]]),nrow=Dim)
        yksum<-matrix(c(yksum[,-dif[1]]),nrow=Dim)
        ykmean<-matrix(c(ykmean[,-dif[1]]),nrow=Dim)
        yksumsquar<-matrix(c(yksumsquar[,-dif[1]]),nrow=Dim)
        K<-ncol(mupost)}
      if (length(table(Zj))<K){
        mupost<-matrix(c(mupost[,-K]),nrow=Dim)
        lambdapost<-matrix(c(lambdapost[,-K]),nrow=Dim)
        alfapost<-matrix(c(alfapost[,-K]),nrow=Dim)
        betapost<-matrix(c(betapost[,-K]),nrow=Dim)
        yksum<-matrix(c(yksum[,-K]),nrow=Dim)
        ykmean<-matrix(c(ykmean[,-K]),nrow=Dim)
        yksumsquar<-matrix(c(yksumsquar[,-K]),nrow=Dim)
        K<-ncol(mupost)}
      K<-ncol(mupost)}
    if (int>burnin & int%%saltos==0) cat('',Zj,file=paste(directory,"Global_cluster.txt",sep=""),append=T)}
  Nt<-sum(Klocal)
  clust_f<-local_clust(directory,arqu=paste("Global_cluster.txt",sep=""),Nt=Nt,thresh)
  clust_local<-get(paste("clust",1,sep=""))
  for (b in 2:length(shards)) clust_local<-c(clust_local,get(paste("clust",b,sep=""))+max(clust_local))
  for (i in 1:length(clust_local)) clust_local[i]<-clust_f[clust_local[i]]
  ordem<-scan(file=paste(directory,"Shard",1,".txt",sep=""))
  for (b in 2:length(shards)) ordem<-c(ordem,scan(file=paste(directory,"Shard",b,".txt",sep="")))
  ordem<-order(ordem)
  cluster_glo<-clust_local[ordem]
  return(cluster_glo)}

#' SNOB clustering method
#'
#' Carry out the SNOB clustering method
#'
#' @param Y a matrix with the data to be analyzed: rows represent different individuals and colunms represent different variables. Missing values are not allowed.
#' @param batches a integer value which specifies the number of shards the data will be split.
#' @param directory a directory in your computer where the intermediate files will be saved.
#' @param burnin a integer number that represents the number of initial iterations in MCMC chain that will be discarded before starting recording MCMC sample. The default value is 5000.
#' @param amostrasfin a integer number that represents the final lenght of MCMC sample after burnin and jumps. Just those iterations will be saved in intermediate files. The default value is 1000.
#' @param saltos a integer number that represents the lenght of jumps to record a new iteration. It should be greater than 0 and the default value is 5.
#' @param alpha a integer number that represents the value of total mass parameter of Dirichet process. The default value is 1.
#' @param mu0 a column matrix which specifies the value of hyperparameter mu (mean) in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows in this matrix should be the number of variables considered in data analysis. The default value is 0 for all considered variable.
#' @param lambda0 a column matrix which specifies the value of hyperparameter lambda in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis. The default value is 0.1 for all considered variable.
#' @param alfa0 a column matrix which specifies the value of hyperparameter alpha in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis. The default value is 5 for all considered variable.
#' @param beta0 a column matrix which specifies the value of hyperparameter beta in a Normal Inverse Gamma distribution (assumed baseline measure) for parameter theta associated with each variable. The number of rows of this matrix should be the number of variables considered in data analysis. The default value is 3 for all considered variable.
#' @param thresh a real value in (0,100) interval which represents the co-clustering probability threshold to define if two individuals were be in the same cluster or not. We have smaller number of larger clusters for low values of thresh. The default value is 50.
#'
#' @return a numerical vector which represents the final global cluster for each individual for the whole analyzed data. Files called 'Shardb.txt', where b=1,...,batches, will be saved in the specified directory. Those files identify the individuals allocated in each shard. Files called "Sj_batchb.txt", for b=1,...,B, will be saved in the specified directory. Those files consist of the number of the local cluster each individual is allocated in each recorded MCMC iteration. A file called "Global_cluster.txt" will also be saved in the specified directory. That file consists of the number of the global cluster each local cluster of all shards is allocated in each recorded MCMC iteration.
#' @export
#'
#' @examples data(iris)
#' glob_clust<-SnobCluster(Y=iris[,1:4],batches=2,directory="/Users/Daiane/Downloads/",burnin=2000,amostrasfin=1000,saltos=5)
#' glob_clust
#'
SnobCluster<-function(Y,batches,directory,burnin=5000,amostrasfin=1000,saltos=5,alpha=1,mu0=matrix(0,ncol=1,nrow=ncol(shards[[1]])),lambda0=matrix(0.1,nrow=ncol(shards[[1]]),ncol=1),alfa0=matrix(5,nrow=ncol(shards[[1]]),ncol=1),beta0=matrix(3,nrow=ncol(shards[[1]]),ncol=1),thresh=0.5*100){
  dados<-transfdata(Y)
  shards<-split_data_shards(dados=dados,batches=batches,directory=directory)
  enableJIT(3)
  run_local_clusters_parallel(shards=shards,directory=directory,burnin=burnin,amostrasfin=amostrasfin,saltos=saltos,alpha=alpha,mu0=mu0,lambda0=lambda0,alfa0=alfa0,beta0=beta0)
  clusters<-Gibbs_global(directory=directory,shards=shards,name_clustb="clust",burnin=burnin,amostrasfin=amostrasfin,saltos=saltos,alpha=1,mu0=mu0,lambda0=lambda0,alfa0=alfa0,beta0=beta0,thresh=thresh)
  return(clusters)}
#
